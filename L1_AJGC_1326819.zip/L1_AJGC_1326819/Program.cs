﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1_AJGC_1326819
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Ingrese su nombre: ");
            String Nombre = Console.ReadLine();

            Console.WriteLine(" hola mundo ");
            Console.WriteLine(" soy " + Nombre);

            Console.Write(" hola mundo ");
            Console.Write(" soy " + Nombre);

            //WRITE LINE : para escribir una línea de texto 
            //en la consola o en un archivo de texto.

            //  WRITE : se utiliza para escribir texto en la consola o en un archivo
            //  de texto sin agregar automáticamente un saltode línea al final de la cadena escrita

            //   En resumen "WriteLine",  agrega un salto de línea después de escribir el texto, "Write" simplemente coloca el texto
            //   en la salida sin avanzar a la siguiente línea.

            //----COMPILADOR O INTERPRETE PARA EJCUTARSE----- 

            // los proyectos de C# en Visual Studio para Consola utilizan un compilador para traducir el código fuente a código ejecutable antes de su ejecución, en lugar de depender de un intérprete.
            //Cuando se creaa un proyecto en Visual Studio C# para Consola y se compila, el compilador de C# (normalmente el compilador de Microsoft, csc.exe) se encarga de traducir el código fuente
            // en un archivo ejecutable (normalmente con extensión .exe) que puede ser ejecutado en una máquina. Después de la compilación, se puede ejecutar el programa desde Visual Studio o desde la 
            //línea de comandos. Cuando se ejecuta, el sistema operativo carga el archivo ejecutable y comienza a ejecutar el programa.

            //--ENTRADAS--
            // - El ingresar el nombre con el mensaje"("Ingrese su nombre: ");"

            //--PROCESOS-- 
            // -Console.Readline() para leer la entrada del usuario y almacena el nombre ingresado en una variable llamada Nombre.;
            // -Programa concatena el nombre ingresado con la cadena " hola mundo " utilizando la concatenación de cadenas (+) y muestra este mensaje en la consola dos veces, una vez usando
            // Console.WriteLine y otra vez usando Console.Write.

            //--SALIDAS-- 
            // VLa primera línea utiliza Console.WriteLine para mostrar " hola mundo " seguido por el nombre ingresado.
            //La segunda línea utiliza Console.Write para mostrar " hola mundo " seguido por el nombre ingresado sin un salto de línea, por lo que el cursor se mantendrá en la misma línea después de la salida.

            Console.ReadKey();




        }
    }
}
