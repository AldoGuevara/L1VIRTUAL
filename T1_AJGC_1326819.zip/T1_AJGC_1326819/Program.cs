﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1_AJGC_1326819
{
    internal class Program
    {
        static void Main(string[] args)
        {
            

          
            

            Console.WriteLine("MI SEGUNDO PROGRMA");

            Console.WriteLine("Ingrese su nombre ");
            string sNombre = Console.ReadLine();

            Console.WriteLine("Ingrese su edad");
            string sEdad = Console.ReadLine();

            Console.WriteLine("Ingrese su carrera ");
            string sCarrera = Console.ReadLine();

            Console.WriteLine("Ingrese su carne ");
            string sCarne = Console.ReadLine();

            Console.WriteLine("MENSAJE");

            Console.WriteLine(" Soy " + sNombre + " tengo " + sEdad + " años y estudio la carrera de " + sCarrera + " ,Mi número de carné es; " + sCarne );


            Console.ReadKey();  

        }//CIERRE 3
    }//CIERRE 2
}//CIERRE 1
